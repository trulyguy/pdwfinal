import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pass-recover',
  templateUrl: './pass-recover.component.html',
  styleUrls: ['./pass-recover.component.css']
})
export class PassRecoverComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
