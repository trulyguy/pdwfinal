import { DecimalPipe } from "@angular/common";1

export interface IDespesa {
    id: number,
    nome: string,
    valor: string,
    tipo: string,
}