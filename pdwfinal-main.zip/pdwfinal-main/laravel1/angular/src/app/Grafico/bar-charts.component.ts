import { Component, OnInit } from '@angular/core';
import { productSales,productSalesMulti } from 'src/data/products';

@Component({
  selector: 'app-bar-charts',
  templateUrl: './bar-charts.component.html',
  styleUrls: ['./bar-charts.component.css']
})
export class BarChartsComponent implements OnInit {

  productSales: any[] = []; 
  productSalesMulti: any[] = [];
  view: any[1000] = [700];

  // options
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = true;
  showXAxisLabel = true;
  xAxisLabel = 'Country';
  showYAxisLabel = true;
  yAxisLabel = 'Population';

  colorScheme = {
    domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA']
  };
  

  constructor() {Object.assign(this,{ productSales, productSalesMulti}) }

  ngOnInit(): void {
  
  }

  onSelect(event: any) {
    console.log(event);
  }
}
