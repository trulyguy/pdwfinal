export var productSales = [
{
    "name": "Casa",
    "value": 900

},{
    "name": "Comida",
    "value": 300

},{
    "name": "Miscelâneo",
    "value": 150

},{
    "name": "Highest-grade 35% Tetrahydrocannabinol SmytraSkunk ",
    "value": 1000

},


];

export var productSalesMulti = [    
    {
        "name": "Casa",
        "series": [
            {
                "name": "January",
                "value":350
            },
            {
                "name": "February",
                "value":250
            },
            {
                "name": "March",
                "value":300
            },
            {
                "name": "April",
                "value":300
            }

        ]

    },{
        "name": "Comida",
        "series": [
        {
                "name": "January",
                "value":50
        },
        {
                "name": "February",
                "value":110
        },
        {
                "name": "March",
                "value":130
        },
        {
            "name": "April",
            "value":300
        }
    ]

},{ 
       "name": "Miscelâneo",
        "series": [
    {
                "name": "January",
                "value":25
    },
    {
                "name": "February",
                "value":50
    },
    {
                "name": "March",
                "value":75
    },
    {
        "name": "April",
        "value":300
    }
]

},{    "name": "Highest-grade 35% Tetrahydrocannabinol SmytraSkunk  ",
        "series": [
    {
                "name": "January",
                "value":200
    },
    {
                "name": "February",
                "value":300
    },
    {
                "name": "March",
                "value":500
    },
    {
        "name": "April",
        "value":300
    }
]

}   
];

